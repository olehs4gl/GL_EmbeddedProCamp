
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"
#include "EventRecorder.h"

#define STACK_SIZE 200
#define PRIORITY 3

/* Private variables ---------------------------------------------------------*/
osThreadId defaultTaskHandle;

StaticTask_t xTaskBuffer;

StackType_t xStack[STACK_SIZE];

TaskHandle_t xsHandle = NULL;

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
void StartDefaultTask(void const * argument);


char tblink(short b_start,short b_end){
if(((short)( TIM3 -> CNT ) > b_start) && ((short)( TIM3 -> CNT ) < b_end)) return 1;
return 0;
}

void vTaskCode1(){

	static char on_off=0;
	char t_on_off;
	for(;;)
	{
		t_on_off = tblink(1000,10000);
		if(t_on_off != on_off)
		{
			on_off = t_on_off;
			if(on_off)
			{
				GPIOE -> BSRR = GPIO_BSRR_BS_8;
			}
			else
			{
				GPIOE -> BSRR = GPIO_BSRR_BR_8;
			}
		}
//		osDelay(1);
//	osThreadResume(myTask02Handle);
//	osThreadSuspend(NULL);
	}

}

void vTaskCode2(){

	static char on_off=0;
	char t_on_off;
	for(;;)
	{
		t_on_off = tblink(2000,8000) + tblink(12000,18000);
		if(t_on_off != on_off)
		{
			on_off = t_on_off;
			if(on_off)
			{
				GPIOE -> BSRR = GPIO_BSRR_BS_9;
			}
			else
			{
				GPIOE -> BSRR = GPIO_BSRR_BR_9;
			}
		}
	}

}


void vTaskCode3(){

	static char on_off=0;
	char t_on_off;
	for(;;)
	{
		t_on_off = tblink(5000,15000);
		if(t_on_off != on_off)
		{
			on_off = t_on_off;
			if(on_off)
			{
				GPIOE -> BSRR = GPIO_BSRR_BS_10;
			}
			else
			{
				GPIOE -> BSRR = GPIO_BSRR_BR_10;
			}
		}
	}

}


void vTaskCodeS(){

	static char on_off=0;
	char t_on_off;
	for(;;)
	{
		t_on_off = tblink(200,3500) + tblink(9200,10800) + tblink(16000,19000);
		if(t_on_off != on_off)
		{
			on_off = t_on_off;
			if(on_off)
			{
				GPIOE -> BSRR = GPIO_BSRR_BS_11;
			}
			else
			{
				GPIOE -> BSRR = GPIO_BSRR_BR_11;
			}
		}
	}

}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* Configure the system clock */
  SystemClock_Config();

  /* Initialize all configured peripherals */
  MX_GPIO_Init();

	// Configure LED3, LED4, LED5, LED6, LED7, LED8, LED9 and LED10
	RCC -> AHBENR  |= 0x00200000;//GPIOE clock enable
	GPIOE -> MODER   |= 0x55550000;//PE8-15 output
	GPIOE -> OSPEEDR |= 0xFFFF0000;//PE8-15

	RCC -> APB1ENR	|= 0x00000002;//__TIM3_CLK_ENABLE();
	TIM3 -> PSC = 7199;
	TIM3 -> ARR = 19999;
	TIM3 -> CR1 |= 0x00000001;

	EventRecorderInitialize (EventRecordAll, 1);
	
	vTraceEnable(TRC_START);

/* Create the thread(s) */
  /* definition and creation of defaultTask */
  osThreadDef(defaultTask, StartDefaultTask, osPriorityNormal, 0, 128);
  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);

  TaskHandle_t xHandle1,xHandle2,xHandle3;
  if( xTaskCreate ( vTaskCode1,  "Task 1",  128,  NULL,  osPriorityNormal,  &xHandle1  ) != pdPASS )
  {;}/* The task was not created successfully. */
  else {;}

  if( xTaskCreate ( vTaskCode2,  "Task 2",  128,  NULL,  osPriorityNormal,  &xHandle2  ) != pdPASS )
  {;}/* The task was not created successfully. */
  else {;}

  if( xTaskCreate ( vTaskCode3,  "Task 3",  128,  NULL,  osPriorityNormal,  &xHandle3  ) != pdPASS )
  {;}/* The task was not created successfully. */
  else {;}

  /* Use the handle to raise the priority of the created task. */
//  vTaskPrioritySet ( xHandle1, 2 );
//  vTaskDelete( xHandle1 );
//  vTaskDelete( xHandle2 );
//  vTaskDelete( xHandle3 );

  xsHandle = xTaskCreateStatic(vTaskCodeS,"StaticTask",STACK_SIZE,(void*)1,osPriorityNormal,xStack,&xTaskBuffer);


  /* Start scheduler */
  osKernelStart();
  
  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}


void vApplicationIdleHook( void ){

	volatile int i = 25;

	while (i)
	{
		i--;
	}
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOF_CLK_ENABLE();

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used 
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void const * argument)
{
  /* USER CODE BEGIN 5 */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END 5 */ 
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(char *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
